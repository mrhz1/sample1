import asyncio
import logging
import uvicorn
import os
from fastapi import FastAPI
import cmlapi
import requests
import asyncio

PROJECT_ID = os.environ["CDSW_PROJECT_ID"]
JOB_NAME = "Test"


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)

logger = logging.getLogger("FastAPI")


app = FastAPI()


client = cmlapi.default_client()


async def get_or_create_job():

    jobs = client.list_jobs(
        project_id=PROJECT_ID
    )
    print(jobs)

    for job in jobs.jobs:
        if job.name == JOB_NAME:
            return job


    job_request = cmlapi.CreateJobRequest(
        name=JOB_NAME,
        script="test_job.py",
        kernel="python3",
    )


    job = client.create_job(
        job_request,
        project_id=PROJECT_ID,
    )

    return job



async def start_job(job):

    try:
        runs = client.list_job_runs(
            project_id=PROJECT_ID,
            job_id=job.id,
        )

        for run in runs.job_runs:

            if str(run.status).upper() in [
                "RUNNING",
                "STARTING",
                "SCHEDULED",
                "PENDING",
            ]:
                logger.info(
                    "Existing active job run found: %s",
                    run.id
                )

                return run.id

    except Exception as e:
        logger.warning(
            "Could not check existing runs: %s",
            e
        )


    logger.info(
        "Starting new job run"
    )

    run_request = cmlapi.CreateJobRunRequest()

    run = client.create_job_run(
        run_request,
        project_id=PROJECT_ID,
        job_id=job.id,
    )

    return run.id



async def monitor_job_logs(job_id, run_id):

    domain = os.environ["CDSW_DOMAIN"]
    token = os.environ["CDSW_API_KEY"]

    url = (
        f"https://{domain}/api/v2/"
        f"projects/{PROJECT_ID}/jobs/{job_id}"
        f"/runs/{run_id}"
    )

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    logger.info(
        "Monitoring job run: %s",
        url
    )

    while True:

        try:

            response = requests.get(
                url,
                headers=headers,
                verify=True,
                timeout=30
            )

            logger.info(
                "Run API status=%s response=%s",
                response.status_code,
                response.text[:500]
            )

        except Exception as e:

            logger.error(
                "Monitor error: %s",
                e
            )

        await asyncio.sleep(5)



@app.on_event("startup")
async def startup():

    logger.info(
        "Starting FastAPI"
    )


    job = await get_or_create_job()


    logger.info(
        "Starting job: %s",
        job.name
    )


    run_id = await start_job(job)


    logger.info(
        "Job started. Run ID: %s",
        run_id
    )


    asyncio.create_task(
      monitor_job_logs(job.id, run_id)
    )



@app.get("/")
def root():

    return {
        "status": "running"
    }



if __name__ == "__main__":

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8002,
        reload=True,
    )
