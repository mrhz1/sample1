from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

DIST = Path(__file__).parent / "dist"
app = FastAPI()


@app.get("/api/hello")
def hello():
    return {"msg": "Hello"}


app.mount("/assets", StaticFiles(directory=DIST / "assets"))


@app.get("/")
def root():
    return FileResponse(DIST / "index.html")


@app.get("/{fill_path:path}")
def spa(full_path: str):
    return FileResponse(DIST / "index.html")
