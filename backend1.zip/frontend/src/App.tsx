import Distance from "./Distance";

/* -------------------------------------------------------------------------- */

export default function App() {
  return (
    <div>
      <Distance />
    </div>
  );
}
