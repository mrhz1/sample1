export interface Location {
  name: string | null;
  address: string | null;
  flyover_distance_km: number | null;
  drive_distance_km: number | null;
  transit_distance_km: number | null;
  drive_duration: number | null;
  transit_duration: number | null;
  flyover_duration: number | null;
}

export interface DistanceResponse {
  postal_code: string;
  locations: Location[];
}

export type Tab = "single" | "csv";
