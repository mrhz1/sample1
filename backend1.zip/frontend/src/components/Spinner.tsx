// Reusable loading spinner component
export function Spinner() {
  return (
    // SVG-based spinner with Tailwind animation
    <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
      {/* Background circle for spinner track */}
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />

      {/* Animated section showing the spinning progress */}
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
      />
    </svg>
  );
}
