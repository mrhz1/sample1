import { type Location } from "../types/destination";

// Props accepted by the DestinationCard component
type DestinationCardProps = {
  location: Location;
};

// Displays distance information for a single destination
const DestinationCard = ({ location }: DestinationCardProps) => {
  const formatDuration = (minutes: number) => {
    if (minutes == null) return "N/A";

    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);

    if (hours > 0) {
      return `${hours} hr ${mins} minutes`;
    }

    return `${mins} minutes`;
  };
  return (
    // Main destination card
    <div className="rounded-2xl bg-white p-6 shadow-sm transition hover:shadow-md">
      {/* Destination name */}
      <h2 className="text-lg font-semibold text-gray-900">{location.name}</h2>

      {/* Destination address */}
      <p className="mt-1 text-sm text-gray-500">
        {location.address || "Address unavailable"}
      </p>

      {/* Distance metrics */}
      <div className="mt-5 grid grid-cols-2 gap-4">
        {/* Driving distance */}
        <div className="rounded-xl bg-blue-50 p-3">
          <p className="text-xs font-medium text-blue-600">Driving</p>
          <p className="mt-1 text-lg font-semibold">
            {location.drive_distance_km == null
              ? "Not Available"
              : `${location.drive_distance_km} km`}
          </p>
          <p className="text-sm text-gray-600">
            {location.drive_duration == null
              ? "N/A"
              : formatDuration(location.drive_duration ?? 0)}
          </p>
        </div>

        {/* Public transit distance */}
        <div className="rounded-xl bg-green-50 p-3">
          <p className="text-xs font-medium text-green-600">Transit</p>
          <p className="mt-1 text-lg font-semibold">
            {location.transit_distance_km == null
              ? "Not Available"
              : `${location.transit_distance_km} km`}
          </p>
          <p className="text-sm text-gray-600">
            {location.transit_duration == null
              ? "N/A"
              : formatDuration(location.transit_duration ?? 0)}
          </p>
        </div>

        {/* Straight-line (flyover) distance */}
        <div className="rounded-xl bg-purple-50 p-3">
          <p className="text-xs font-medium text-purple-600">Flyover</p>
          <p className="mt-1 text-lg font-semibold">
            {location.flyover_distance_km == null
              ? "Not Available"
              : `${location.flyover_distance_km} km`}
          </p>
          <p className="text-sm text-gray-600">
            {location.flyover_duration == null
              ? "N/A"
              : formatDuration(location.flyover_duration ?? 0)}
          </p>
        </div>
      </div>
    </div>
  );
};

export default DestinationCard;
