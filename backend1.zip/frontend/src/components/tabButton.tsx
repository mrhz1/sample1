// Available tabs in the application
type ActiveTab = "single" | "csv";

// Props accepted by the TabButton component
type TabButtonProps = {
  tab: ActiveTab;
  label: string;
  activeTab: ActiveTab;
  setActiveTab: React.Dispatch<React.SetStateAction<ActiveTab>>;
};

// Reusable button used to switch between application tabs
const TabButton = ({ tab, label, activeTab, setActiveTab }: TabButtonProps) => {
  return (
    <button
      // Update the active tab when clicked
      onClick={() => setActiveTab(tab)}
      // Apply different styles depending on whether this tab is selected
      className={`flex-1 cursor-pointer rounded-lg px-4 py-2 text-sm font-medium transition ${
        activeTab === tab ? "bg-white text-blue-600 shadow-sm" : "text-gray-600"
      }`}
    >
      {/* Display the tab label */}
      {label}
    </button>
  );
};

export default TabButton;
