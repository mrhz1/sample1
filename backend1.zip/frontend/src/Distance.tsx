import { useState } from "react";
import { Spinner } from "./components/Spinner";
import { type Tab, type DistanceResponse } from "./types/destination";
import TabButton from "./components/tabButton";
import DestinationCard from "./components/DestinationCard";
export default function Distance() {
  // ============================================================
  // Tab State
  // ============================================================
  const [activeTab, setActiveTab] = useState<Tab>("single");

  // ============================================================
  // Single Search State
  // ============================================================
  const [postalCode, setPostalCode] = useState("");
  const [data, setData] = useState<DistanceResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // ============================================================
  // CSV Upload State
  // ============================================================
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvLoading, setCsvLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [csvError, setCsvError] = useState("");

  // ============================================================
  // Handle Single Postal Code Search
  // ============================================================
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!postalCode.trim()) return;
    setLoading(true);
    setError("");
    setData(null);
    try {
      const response = await fetch(
        `https://hospitaldistance.research.sickkids.ca/api/estimate/${postalCode}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        },
      );
      if (!response.ok) {
        throw new Error("Failed to fetch distances");
      }
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }
  // ============================================================
  // Handle CSV/XLSX Upload
  // ============================================================
  async function handleCsvUpload() {
    if (!csvFile) return;
    setCsvLoading(true);
    setCsvError("");
    setUploadedFile(null);
    setDownloadUrl(null);
    try {
      const formData = new FormData();
      formData.append("file", csvFile);
      const response = await fetch(
        "https://hospitaldistance.research.sickkids.ca/api/upload-csv",
        {
          method: "POST",
          body: formData,
        },
      );
      if (!response.ok) {
        throw new Error("CSV upload failed");
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      setDownloadUrl(url);
      setUploadedFile("processed_result.xlsx");
    } catch (err) {
      setCsvError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setCsvLoading(false);
    }
  }
  // ============================================================
  // Render
  // ============================================================
  return (
    <div className="min-h-screen bg-gray-50 px-6 py-12">
      {" "}
      <div className="mx-auto max-w-4xl">
        {" "}
        {/* ================= Header ================= */}
        <div className="mb-8 text-center">
          {" "}
          <h1 className="text-3xl font-semibold tracking-tight text-gray-900">
            {" "}
            Hospital Distance Finder{" "}
          </h1>{" "}
          <p className="mt-2 text-gray-500">
            {" "}
            Enter your postal code to calculate travel distances{" "}
          </p>{" "}
        </div>{" "}
        {/* ================= Navigation Tabs ================= */}
        <div className="mx-auto mb-8 flex max-w-md rounded-xl bg-gray-200 p-1">
          {" "}
          <TabButton
            tab="single"
            label="Single Search"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />{" "}
          <TabButton
            tab="csv"
            label="CSV"
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />{" "}
        </div>{" "}
        {/* ================= Single Search ================= */}
        {activeTab === "single" && (
          <>
            {" "}
            {/* Search Form */}
            <form
              onSubmit={handleSubmit}
              className="mx-auto flex max-w-xl gap-3"
            >
              {" "}
              <input
                value={postalCode}
                onChange={(e) => setPostalCode(e.target.value)}
                placeholder="e.g. A1A 1A1"
                className="flex-1 rounded-xl border border-gray-300 bg-white px-4 py-3 text-gray-900 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              />{" "}
              <button
                disabled={loading}
                className="flex items-center justify-center rounded-xl bg-blue-600 px-6 py-3 font-medium text-white transition hover:bg-blue-700 disabled:opacity-60"
              >
                {" "}
                {loading ? (
                  <span className="flex items-center gap-2">
                    {" "}
                    <Spinner /> Searching{" "}
                  </span>
                ) : (
                  "Search"
                )}{" "}
              </button>{" "}
            </form>{" "}
            {/* Error Message */}
            {error && (
              <div className="mx-auto mt-6 max-w-xl rounded-xl bg-red-50 p-4 text-red-600">
                {" "}
                {error}{" "}
              </div>
            )}{" "}
            {/* Search Results */}
            {data && (
              <div className="mt-10">
                {" "}
                <div className="mb-6 rounded-xl bg-white p-5 shadow-sm">
                  {" "}
                  <p className="text-sm text-gray-500">
                    {" "}
                    Starting location{" "}
                  </p>{" "}
                  <p className="mt-1 text-xl font-semibold text-gray-900">
                    {" "}
                    {data.postal_code}{" "}
                  </p>{" "}
                </div>{" "}
                <div className="grid gap-5 md:grid-cols-2">
                  {" "}
                  {data.locations.map((location) => (
                    <DestinationCard key={location.name} location={location} />
                  ))}{" "}
                </div>{" "}
              </div>
            )}{" "}
          </>
        )}{" "}
        {/* ================= CSV Upload ================= */}
        {activeTab === "csv" && (
          <div className="rounded-2xl bg-white p-6 shadow-sm">
            {" "}
            <h2 className="text-xl font-semibold text-gray-900">
              {" "}
              Bulk Distance Upload{" "}
            </h2>{" "}
            <p className="mt-1 text-sm text-gray-500">
              {" "}
              Upload a CSV file and download the calculated results{" "}
            </p>{" "}
            {/* Upload Form */}
            <div className="mt-5 flex flex-col gap-4 sm:flex-row">
              {" "}
              <label className="flex-1 cursor-pointer rounded-xl border border-dashed border-gray-300 bg-gray-50 px-4 py-3 text-sm text-gray-600 hover:bg-blue-50">
                {" "}
                <input
                  type="file"
                  accept=".csv,.xlsx"
                  className="hidden"
                  onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                />{" "}
                {csvFile ? csvFile.name : "Choose CSV file"}{" "}
              </label>{" "}
              <button
                onClick={handleCsvUpload}
                disabled={!csvFile || csvLoading}
                className="rounded-xl bg-blue-600 px-6 py-3 font-medium text-white hover:bg-blue-700 disabled:opacity-50"
              >
                {" "}
                {csvLoading ? (
                  <span className="flex gap-2 items-center">
                    {" "}
                    <Spinner /> Uploading{" "}
                  </span>
                ) : (
                  "Upload CSV/XLSX"
                )}{" "}
              </button>{" "}
            </div>{" "}
            {/* Upload Error */}
            {csvError && (
              <div className="mt-4 rounded-xl bg-red-50 p-3 text-red-600">
                {" "}
                {csvError}{" "}
              </div>
            )}{" "}
            {/* Download Result */}
            {uploadedFile && downloadUrl && (
              <div className="mt-6 flex items-center justify-between rounded-xl bg-green-50 p-4">
                {" "}
                <div>
                  {" "}
                  <p className="text-sm font-medium text-green-700">
                    {" "}
                    File ready{" "}
                  </p>{" "}
                  <p className="text-sm text-gray-700"> {uploadedFile} </p>{" "}
                </div>{" "}
                <a
                  href={downloadUrl}
                  download={"processed_result.xlsx"}
                  className="rounded-lg bg-green-600 px-4 py-2 text-sm font-medium text-white hover:bg-green-700"
                >
                  {" "}
                  Download{" "}
                </a>{" "}
              </div>
            )}{" "}
          </div>
        )}{" "}
      </div>{" "}
    </div>
  );
}
