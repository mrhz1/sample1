# Hospital Distance Finder

A React + TypeScript application that calculates travel distances between a user's postal code and hospital destinations.

The application supports:
- Single postal code distance lookup
- Bulk CSV/XLSX upload for processing multiple locations
- Displaying driving, public transit, and straight-line distances
- Downloading processed distance results

---

## Features

### Single Search
- Enter a postal code to find nearby hospital distance information
- Displays:
  - Driving distance and duration
  - Public transit distance and duration
  - Straight-line (flyover) distance

### CSV/XLSX Bulk Upload
- Upload a CSV or Excel file containing locations
- Backend processes the file
- Download the generated result file

### User Interface
- Responsive layout
- Tab-based navigation
- Loading states with reusable spinner component
- Error handling for failed API requests
- Modern UI built with Tailwind CSS

---

## Tech Stack

### Frontend
- React 19
- TypeScript
- Vite
- Tailwind CSS 4
- pnpm

### Development Tools
- ESLint
- TypeScript Compiler
- Vite Development Server

---
## Project Structure

```text
src/
│
├── components/
│   ├── DestinationCard.tsx   # Displays destination distance information
│   ├── Spinner.tsx           # Loading spinner component
│   └── tabButton.tsx         # Tab navigation component
│
├── types/
│   └── destination.ts        # TypeScript interfaces and types
│
├── App.tsx                   # Root application component
├── Destination.tsx           # Main distance finder logic and UI
├── main.tsx                  # Application entry point
└── index.css                 # Global styles
```

---
## Requirements

Before running the project, make sure you have the following installed:

- Node.js
- pnpm

To verify that pnpm is installed, run:

```bash
pnpm --version
```
---
## Installation

Clone the repository:

```bash
git clone <repository-url>
```

Navigate into the project directory:

```bash
cd frontend
```

Install dependencies:

```bash
pnpm install
```

---

## Running the Application

Start the development server:

```bash
pnpm dev
```

The application will be available at:

```text
http://localhost:5173
```

---

## Backend API Requirements

This frontend expects a backend server running locally at:

```text
http://localhost:8000
```

---

## API Endpoints

### 1. Distance Search

**Endpoint**

```http
POST /distance
```

### Request

```json
{
  "postal_code": "A1A 1A1"
}
```

### Response

```json
{
  "origin": "A1A 1A1",
  "destinations": [
    {
      "location": "Example Hospital",
      "address": "123 Example Street",
      "flyover_distance": 5.2,
      "drive_distance_km": 7.4,
      "transit_distance_km": 8.1,
      "drive_duration": "15 mins",
      "transit_duration": "35 mins",
      "flyover_duration": "6 mins"
    }
  ]
}
```

---

### 2. CSV/XLSX Upload

**Endpoint**

```http
POST /upload-csv
```

### Request

Multipart form upload:

```text
file: <csv/xlsx file>
```

### Response

Returns a processed Excel file:

```text
processed_result.xlsx
```

---

## Environment Configuration

Currently, API URLs are hardcoded:

```text
http://localhost:8000
```

For production usage, consider moving API configuration into environment variables.

Example:

```env
VITE_API_URL=http://localhost:8000
```

Then access it in the application using:

```ts
const API_URL = import.meta.env.VITE_API_URL;
```

---

## Example

```env
VITE_API_URL=http://localhost:8000
```

Then use:

```ts
const API_URL = import.meta.env.VITE_API_URL;
```

---

## Components Overview

### DestinationCard

Responsible for rendering distance information for each destination.

Displays:

- Destination name
- Address
- Driving metrics
- Transit metrics
- Flyover distance

---

### Spinner

Reusable SVG loading indicator used during:

- Postal code searches
- File uploads

---

### TabButton

Reusable navigation button component used to switch between:

- Single Search
- CSV Upload

---