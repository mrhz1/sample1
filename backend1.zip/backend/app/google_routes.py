import requests

from app.config import GOOGLE_MAPS_API_KEY
from app.locations import DESTINATIONS
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

import io
import pandas as pd
import math


def calculate_transit_matrix(origin):
    url = "https://routes.googleapis.com/distanceMatrix/v2:computeRouteMatrix"

    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": GOOGLE_MAPS_API_KEY,
        "X-Goog-FieldMask": (
            "originIndex,"
            "destinationIndex,"
            "duration,"
            "distanceMeters,"
            "status,"
            "condition,"
            "travelAdvisory.transitFare"
        ),
    }

    destinations = []

    for location in DESTINATIONS:
        destinations.append(
            {
                "waypoint": {
                    "location": {
                        "latLng": {
                            "latitude": location["latitude"],
                            "longitude": location["longitude"],
                        }
                    }
                }
            }
        )

    body = {
        "origins": [
            {
                "waypoint": {
                    "location": {
                        "latLng": {
                            "latitude": origin["latitude"],
                            "longitude": origin["longitude"],
                        }
                    }
                }
            }
        ],
        "destinations": destinations,
        "travelMode": "TRANSIT",
    }

    response = requests.post(url, json=body, headers=headers)

    data = response.json()

    normalized_results = []

    for item in data:
        # If Google cannot find a route
        if item.get("condition") == "ROUTE_NOT_FOUND":
            item["distanceMeters"] = "NOT_FOUND"

            item["duration"] = "NOT_FOUND"

            item["travelAdvisory"] = {"transitFare": {}}

        else:
            # Make sure missing optional fields exist
            item.setdefault("distanceMeters", "NOT_FOUND")

            item.setdefault("duration", "NOT_FOUND")

            item.setdefault("travelAdvisory", {"transitFare": {}})

        normalized_results.append(item)

    return normalized_results


def calculate_fly_over(origin):
    normalized_results = []

    for location in DESTINATIONS:
        # If Google cannot find a route
        #     return {
        #     "distance_km": round(distance_km, 2),
        #     "cruise_time_min": cruise_minutes / 60,
        #     "taxi_departure_min": taxi_departure / 60,
        #     "takeoff_climb_min": takeoff_climb / 60,
        #     "descent_landing_min": descent_landing / 60,
        #     "taxi_arrival_min": taxi_arrival / 60,
        #     "total_flight_time_min": round(total_minutes / 60),
        #     "total_flight_time_hr_min": f"{int(total_minutes // 60)}h {int(total_minutes % 60)}m",
        # }
        flyover = estimate_flight_time(
            origin["latitude"],
            origin["longitude"],
            float(location["latitude"]),
            float(location["longitude"]),
        )
        normalized_results.append(
            {
                "distanceKMs": flyover["distance_km"],
                "duration": flyover["total_flight_time_hr_min"],
            },
        )

    return normalized_results


def geocode_address(address):

    url = "https://maps.googleapis.com/maps/api/geocode/json"

    params = {"address": address, "key": GOOGLE_MAPS_API_KEY}

    response = requests.get(url, params=params)

    data = response.json()

    if data["status"] != "OK":
        raise Exception(data["status"])

    location = data["results"][0]["geometry"]["location"]

    return {"latitude": location["lat"], "longitude": location["lng"]}


def calculate_route_matrix(origin):

    url = "https://routes.googleapis.com/distanceMatrix/v2:computeRouteMatrix"

    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": GOOGLE_MAPS_API_KEY,
        "X-Goog-FieldMask": "originIndex,destinationIndex,distanceMeters,duration",
    }

    destinations = []

    for location in DESTINATIONS:
        destinations.append(
            {
                "waypoint": {
                    "location": {
                        "latLng": {
                            "latitude": location["latitude"],
                            "longitude": location["longitude"],
                        }
                    }
                }
            }
        )

    body = {
        "origins": [
            {
                "waypoint": {
                    "location": {
                        "latLng": {
                            "latitude": origin["latitude"],
                            "longitude": origin["longitude"],
                        }
                    }
                }
            }
        ],
        "destinations": destinations,
        "travelMode": "DRIVE",
        "units": "METRIC",
        "routingPreference": "TRAFFIC_AWARE",
        # "trafficModel": "OPTIMISTIC",
    }

    response = requests.post(url, json=body, headers=headers)
    return response.json()


# def calculate_route_matrix(origin):

#     # url = "https://routes.googleapis.com/distanceMatrix/v2:computeRouteMatrix"
#     url = "https://routes.googleapis.com/directions/v2:computeRoutes"

#     headers = {
#         "Content-Type": "application/json",
#         "X-Goog-Api-Key": GOOGLE_MAPS_API_KEY,
#         "X-Goog-FieldMask": "routes.duration,routes.distanceMeters",
#     }

#     destinations = []
#     dest = DESTINATIONS[2]
#     coords = geocode_address(dest["address"])
#     destination = {
#         "location": {
#             "latLng": {
#                 "latitude": coords["latitude"],
#                 "longitude": coords["longitude"],
#             }
#         }
#     }
#     # for location in DESTINATIONS[0]:
#     #     coords = geocode_address(location["address"])

#     #     destinations.append(
#     #         {
#     #             "waypoint": {
#     #                 "location": {
#     #                     "latLng": {
#     #                         "latitude": coords["latitude"],
#     #                         "longitude": coords["longitude"],
#     #                     }
#     #                 }
#     #             }
#     #         }
#     #     )

#     body = {
#         "origin": {
#             "location": {
#                 "latLng": {
#                     "latitude": origin["latitude"],
#                     "longitude": origin["longitude"],
#                 }
#             }
#         },
#         "destination": destination,
#         "travelMode": "DRIVE",
#         "routingPreference": "TRAFFIC_AWARE_OPTIMAL",
#         "routeModifiers": {
#             "avoidTolls": True,
#             "avoidHighways": True,
#         },
#         "units": "METRIC",
#         "trafficModel": "OPTIMISTIC",
#     }


#     response = requests.post(url, json=body, headers=headers)
#     return response.json()
def sort_by_destination_index(destinations):
    return sorted(
        destinations,
        key=lambda item: item["destinationIndex"],
    )


def get_distances(postal_code):
    origin = geocode_address(postal_code + ", Ontario, Canada")

    matrix = calculate_route_matrix(origin)
    transit = calculate_transit_matrix(origin)
    flyover = calculate_fly_over(origin)
    sorted_drive = sort_by_destination_index(matrix)
    sorted_transit = sort_by_destination_index(transit)
    results = []

    for index, (drive, transit, flyover) in enumerate(
        zip(sorted_drive, sorted_transit, flyover)
    ):
        results.append(
            {
                "location": DESTINATIONS[index]["name"],
                "address": DESTINATIONS[index]["address"],
                "drive_distance_km": round(drive["distanceMeters"] / 1000, 2),
                "transit_distance_km": (
                    round(transit["distanceMeters"] / 1000, 2)
                    if isinstance(transit.get("distanceMeters"), int)
                    else transit.get("distanceMeters")
                ),
                "drive_duration": convert_to_hr_mins(drive["duration"]),
                "transit_duration": convert_to_hr_mins(transit["duration"]),
                "flyover_distance": flyover["distanceKMs"],
                "flyover_duration": flyover["duration"],
            }
        )

    return results


def convert_to_hr_mins(time_str):
    if time_str == "NOT_FOUND":
        return time_str

    seconds = int(time_str.rstrip("s"))

    hours = seconds // 3600
    minutes = (seconds % 3600) // 60

    return f"{hours} hr {minutes} min"


def read_uploaded_file(filename: str, contents: bytes) -> pd.DataFrame:
    """
    Read CSV or XLSX uploaded file and return DataFrame.
    """

    if filename.endswith(".xlsx"):
        return pd.read_excel(io.BytesIO(contents))

    elif filename.endswith(".csv"):
        return pd.read_csv(io.BytesIO(contents))

    else:
        raise ValueError("Only CSV and XLSX files are supported")


def calculate_distances(df, get_distances):
    """
    Calculate distances for every postal code.
    """

    results = []

    for _, row in df.iterrows():
        postal_code = row["postal_code"]
        temporary_id = row["Temporary ID"]

        distances = get_distances(postal_code)

        output_row = {"Temporary ID": temporary_id, "postal_code": postal_code}

        for location in distances:
            name = location["location"]

            output_row[f"{name}_drive_distance_km"] = location["drive_distance_km"]

            output_row[f"{name}_transit_distance_km"] = location["transit_distance_km"]

            output_row[f"{name}_flyover_distance_km"] = location["flyover_distance"]

            output_row[f"{name}_drive_duration"] = location["drive_duration"]

            output_row[f"{name}_transit_duration"] = location["transit_duration"]

            output_row[f"{name}_flyover_duration"] = location["flyover_duration"]

        results.append(output_row)

    return results


def generate_distance_excel(results, destinations, output_path):

    wb = Workbook()

    ws = wb.active
    ws.title = "Distances"

    # First header row

    current_col = 3

    for destination in destinations:
        name = destination["name"]

        ws.merge_cells(
            start_row=1, start_column=current_col, end_row=1, end_column=current_col + 5
        )

        cell = ws.cell(row=1, column=current_col, value=name)

        cell.alignment = Alignment(horizontal="center", vertical="center")

        cell.font = Font(bold=True)

        current_col += 6

    # Second header row
    ws.cell(row=2, column=1, value="Temporary ID")
    ws.cell(row=2, column=2, value="postal_code")
    headers = [
        "drive_distance_km",
        "transit_distance_km",
        "flyover_distance_km",
        "drive_duration",
        "transit_duration",
        "flyover_duration",
    ]

    current_col = 3

    for _ in destinations:
        for header in headers:
            cell = ws.cell(row=2, column=current_col, value=header)

            cell.alignment = Alignment(horizontal="center", vertical="center")

            cell.font = Font(bold=True)

            current_col += 1

    # Data rows

    row_number = 3

    for row in results:
        ws.cell(row=row_number, column=1, value=row["Temporary ID"])
        ws.cell(row=row_number, column=2, value=row["postal_code"])

        current_col = 3

        for destination in destinations:
            name = destination["name"]

            values = [
                row.get(f"{name}_drive_distance_km", ""),
                row.get(f"{name}_transit_distance_km", ""),
                row.get(f"{name}_flyover_distance_km", ""),
                row.get(f"{name}_drive_duration", ""),
                row.get(f"{name}_transit_duration", ""),
                row.get(f"{name}_flyover_duration", ""),
            ]

            for value in values:
                ws.cell(row=row_number, column=current_col, value=value)

                current_col += 1

        row_number += 1

    # Column widths

    for col in range(1, ws.max_column + 1):
        max_length = 0

        column_letter = get_column_letter(col)

        for row in range(1, ws.max_row + 1):
            cell = ws.cell(row=row, column=col)

            if cell.__class__.__name__ == "MergedCell":
                continue

            if cell.value:
                max_length = max(max_length, len(str(cell.value)))

        ws.column_dimensions[column_letter].width = max_length + 3

    ws.freeze_panes = "B3"

    wb.save(output_path)


def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0

    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    )

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def estimate_flight_time(lat1, lon1, lat2, lon2):
    # 1. Distance
    distance_km = haversine_km(lat1, lon1, lat2, lon2)

    # 2. Aircraft assumptions
    cruise_speed = 850  # km/h (typical commercial jet)

    # 3. Cruise time
    cruise_hours = distance_km / cruise_speed
    cruise_minutes = cruise_hours * 60

    # 4. Fixed flight phases (industry averages)
    taxi_departure = 15  # minutes
    takeoff_climb = 20  # minutes
    descent_landing = 25  # minutes
    taxi_arrival = 10  # minutes

    ground_air_ops = taxi_departure + takeoff_climb + descent_landing + taxi_arrival

    # 5. Total time
    total_minutes = cruise_minutes + ground_air_ops

    return {
        "distance_km": round(distance_km, 2),
        "cruise_time_min": cruise_minutes / 60,
        "taxi_departure_min": taxi_departure / 60,
        "takeoff_climb_min": takeoff_climb / 60,
        "descent_landing_min": descent_landing / 60,
        "taxi_arrival_min": taxi_arrival / 60,
        "total_flight_time_min": round(total_minutes / 60),
        "total_flight_time_hr_min": f"{int(total_minutes // 60)}h {int(total_minutes % 60)}m",
    }
