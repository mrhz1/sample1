DESTINATIONS = [
    {
        "name": "Lindsay Freud",
        "address": "The Hospital for Sick Children, Toronto, ON",
        "latitude": "43.65751600982517",
        "longitude": "-79.38654389162433",
    },
    {
        "name": "Adrienn Szabo",
        "address": "McMaster Children's Hospital / McMaster University, Hamilton, ON",
        "latitude": "43.259082160201864",
        "longitude": "-79.91749254347891",
    },
    {
        "name": "Jane Lougheed",
        "address": "Children's Hospital of Eastern Ontario, Ottawa, ON",
        "latitude": "45.40081837446192",
        "longitude": "-75.65130500462355",
    },
    {
        "name": "Mansukhani Gitanjali",
        "address": "The Children's Hospital at London Health Sciences Centre, London, ON",
        "latitude": "42.961160968160726",
        "longitude": "-81.226475204351",
    },
    {
        "name": "Lynne Nield",
        "address": "Sunnybrook Health Sciences Centre, Toronto, ON",
        "latitude": "43.721738051533414",
        "longitude": "-79.37647244639616",
    },
]
