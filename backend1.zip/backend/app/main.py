from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.schemas import DistanceRequest
from fastapi import UploadFile, File
from app.google_routes import (
    get_distances,
    read_uploaded_file,
    calculate_distances,
    generate_distance_excel,
)
from fastapi.responses import FileResponse

from app.locations import DESTINATIONS
from pathlib import Path


app = FastAPI(title="Postal Distance API", root_path="/api")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def home():

    return {"status": "running"}


@app.post("/distance")
def distance(request: DistanceRequest):

    try:
        result = get_distances(request.postal_code)

        return {"origin": request.postal_code, "destinations": result}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/upload-csv")
async def upload_csv(file: UploadFile = File(...)):

    BASE_DIR = Path(__file__).resolve().parent

    contents = await file.read()

    df = read_uploaded_file(file.filename, contents)

    results = calculate_distances(df, get_distances)

    output_path = BASE_DIR / "processed_result.xlsx"

    generate_distance_excel(results, DESTINATIONS, output_path)

    return FileResponse(
        path=output_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename="processed_result.xlsx",
    )
