from pydantic import BaseModel


class DistanceRequest(BaseModel):
    postal_code: str
