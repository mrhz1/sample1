# Postal Distance API

A FastAPI application that calculates **driving**, **public transit**, and **estimated flight ("flyover")** distances and travel times from an Ontario postal code to a predefined list of medical specialists using the Google Maps Routes API.

The application also supports **bulk processing** by uploading a CSV or Excel file containing postal codes and downloading the calculated results as a formatted Excel workbook.

---

## Features

- Convert an Ontario postal code into geographic coordinates using the Google Geocoding API.
- Calculate driving distance and travel time.
- Calculate public transit distance and travel time.
- Estimate straight-line ("flyover") distance and flight duration using the Haversine formula.
- Upload CSV or Excel files for batch processing.
- Export results into a formatted Excel workbook.
- REST API built with FastAPI.

---

## Project Structure

```
app/
│
├── config.py              # Environment configuration
├── google_routes.py       # Google Maps API integration & calculations
├── locations.py           # Destination locations
├── main.py                # FastAPI application
├── schemas.py             # Request models
│
├── processed_result.xlsx  # Generated output (created automatically)
│
└── requirements.txt
```

---

## Destinations

The application currently calculates distances to the following locations:

| Name | Organization |
|------|--------------|
| Lindsay Freud | The Hospital for Sick Children (Toronto) |
| Adrienn Szabo | McMaster Children's Hospital (Hamilton) |
| Jane Lougheed | Children's Hospital of Eastern Ontario (Ottawa) |
| Mansukhani Gitanjali | London Health Sciences Centre (London) |
| Lynne Neild | Toronto |

Additional destinations can be added in:

```
app/locations.py
```

---

# Installation

## 1. Clone the repository

```bash
git clone https://github.com/yourusername/postal-distance-api.git

cd postal-distance-api
```

---

## 2. Create a virtual environment

### Windows

```bash
python -m venv venv

venv\Scripts\activate
```

### macOS / Linux

```bash
python3 -m venv venv

source venv/bin/activate
```

---

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

---

## 4. Configure environment variables

Create a `.env` file in the project root.

```env
GOOGLE_MAPS_API_KEY=YOUR_GOOGLE_MAPS_API_KEY
```

The application loads this automatically using `python-dotenv`.

---

## 5. Enable Google APIs

Your Google Cloud project must have:

- Geocoding API
- Routes API

enabled.

---

## Running the Application

```bash
uvicorn app.main:app --reload
```

The API will be available at

```
http://127.0.0.1:8000
```

Swagger documentation:

```
http://127.0.0.1:8000/docs
```

---

# API Endpoints

## Health Check

### GET /

Returns application status.

### Response

```json
{
  "status": "running"
}
```

---

## Calculate Distance

### POST /distance

Calculates all travel information for one postal code.

### Request

```json
{
    "postal_code": "L6R1A1"
}
```

### Response

```json
{
  "origin": "L6R1A1",
  "destinations": [
    {
      "location": "Lindsay Freud",
      "address": "The Hospital for Sick Children, Toronto, ON",
      "drive_distance_km": 42.8,
      "transit_distance_km": 39.6,
      "drive_duration": "0 hr 45 min",
      "transit_duration": "1 hr 12 min",
      "flyover_distance": 31.45,
      "flyover_duration": "1h 12m"
    }
  ]
}
```

---

## Upload CSV / Excel

### POST /upload-csv

Uploads a CSV or Excel spreadsheet containing postal codes and returns a processed Excel workbook.

Supported formats:

- CSV
- XLSX

Required column:

```
postal_code
```

Example:

| postal_code |
|-------------|
| L6R1A1 |
| M5G2C4 |
| K1H8L1 |

The API returns a downloadable Excel file containing all calculated distances and durations.

---

# Flight Time Estimation

The application estimates flight time using the Haversine formula.

Assumptions:

- Cruise speed: **850 km/h**
- Taxi before departure: **15 min**
- Takeoff and climb: **20 min**
- Descent and landing: **25 min**
- Taxi after landing: **10 min**

This produces an estimated total flight duration.

---

# Excel Output

The generated workbook contains:

- Postal code
- Drive distance
- Transit distance
- Flyover distance
- Drive duration
- Transit duration
- Flyover duration

Each destination is grouped under its own header for improved readability.

---

# Technologies

- FastAPI
- Google Routes API
- Google Geocoding API
- Pandas
- OpenPyXL
- Requests
- Python Dotenv
- Pydantic

---

# Requirements

Major dependencies:

```
FastAPI
Uvicorn
Requests
Pandas
OpenPyXL
Pydantic
Python Dotenv
```

Install everything with:

```bash
pip install -r requirements.txt
```

---

# Example Workflow

1. User submits a postal code.
2. Postal code is geocoded into latitude/longitude.
3. Google Routes API calculates:
   - Driving distance
   - Driving duration
   - Transit distance
   - Transit duration
4. The application estimates flight distance and time.
5. Results are returned as JSON.

For batch processing:

1. Upload CSV/Excel.
2. Every postal code is processed.
3. Results are compiled.
4. A formatted Excel workbook is generated and downloaded.

---